## Purpose

Describe the problem and the exact result of this change.

## Scope

- Branch: `backend/...`, `frontend/...`, or `qa/...`
- Changed files:
- Explicitly unchanged files:

## Verification

- [ ] `python scripts/verify_artifacts.py`
- [ ] `python -m unittest discover -s tests -v`
- [ ] `git diff --check`
- [ ] Relevant manual checks are listed below

Manual evidence:

## Scientific and safety invariants

- [ ] The locked test partition and reported baseline metrics are unchanged, or the scientific change is explicitly justified and reproduced.
- [ ] Any A/B comparison uses identical input bytes and the same dependency environment.
- [ ] The trained model and scientific core were not changed outside a declared scientific task.
- [ ] Uploaded images are not persisted or logged.
- [ ] The interface does not present the output as a diagnosis or a clinically validated decision.
- [ ] IDRiD attribution and licensing remain intact.

## Reviewer notes

List known limitations, follow-up work, or decisions that require QA attention.
